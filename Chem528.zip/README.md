# Hello Everyone
Welcome to the Chem528 Python workbook. To launch this project, simply log in to [https://notebooks.azure.com/](https://notebooks.azure.com/) using your university account. Return to [https://notebooks.azure.com/mtmarty/projects/chem528](https://notebooks.azure.com/mtmarty/projects/chem528) and click "Clone" to copy these files into your own project folder under your account. Then, launch AA.ipynb (you may have to scroll through the files to find it) and start working through the worksheet. Let me know if there are any questions. 

Note: you need to clone the entire Chem528 project to your account. If you try to run it in my account without cloning it, you won't be able to launch the notebook properly, and it will just look like text. If you don't clone all the files, you will not be able to process the data. 

Note 2: The Microsoft server can be slow sometimes for plotting. I picked it because it has an easy clone feature and didn't require you to create an account. If you want to try another server, there are a few available, and they are relatively easy to figure out. You will need to download all of the files from here and then upload them to the new server. One option is from Google (https://colab.research.google.com/). You can also download Python and Jupyter and [install it on your own computer](https://jupyter.readthedocs.io/en/latest/install.html). Feel free to try these if you are interested or experiencing problems with the server. 

Good luck! 

-MTM